package code.Rendering.Meshes;

import code.Gameplay.Map.LightMapper;
import code.Math.MathUtils;
import code.Rendering.DirectX7;
import code.Rendering.Texture;
import code.Rendering.TexturingAffine;
import code.Rendering.TexturingPers;
import code.Rendering.Vertex;
import code.utils.Main;

/**
 *
 * @author Roman Lahin
 */
public class ColorLightedPolygon3V extends Polygon3V {

    public volatile int ar,ag,ab;
    public volatile int br,bg,bb;
    public volatile int cr,cg,cb;
    
    private static int q,sz2;
    private static int sizex,sizey,sizeu,sizev;
    private static int addmip,fog;
    
    public ColorLightedPolygon3V(ColorLightedPolygon3V p) {
        super((Polygon3V)p);
        ar=p.ar; ag=p.ag; ab=p.ab;
        br=p.br; bg=p.bg; bb=p.bb;
        cr=p.cr; cg=p.cg; cb=p.cb;
    }
    
    public ColorLightedPolygon3V(Vertex a2, Vertex b2, Vertex c2, byte au, byte av, byte bu, byte bv, byte cu, byte cv) {
        super(a2, b2, c2, au, av, bu, bv, cu, cv);
        ar=ag=ab=br=bg=bb=cr=cg=cb=255;
    }
    
public final void render(DirectX7 g3d, Texture texture) {
        if(Main.persQ==0 && Main.mipMapping==false) {renderFast(g3d,texture); return;}
fog=texture.drawmode;

sizex=size(a.sx, b.sx, c.sx);
sizey=size(a.sy, b.sy, c.sy);

// getLight() больше не создаёт массив на каждую вершину:
// результат лежит в общем RenderObject.lightOut, забираем его сразу.
getLight(a,ar,ag,ab,g3d);
int al0=lightOut[0], al1=lightOut[1], al2=lightOut[2];
getLight(b,br,bg,bb,g3d);
int bl0=lightOut[0], bl1=lightOut[1], bl2=lightOut[2];
getLight(c,cr,cg,cb,g3d);
int cl0=lightOut[0], cl1=lightOut[1], cl2=lightOut[2];


if(fog==5) {
sz2=0xff-dirLight(nx, ny, nz);
}

if(fog==1) szCalcfogAdd();


q=(ny>4000 || ny<-4000) ? 9999999 : Main.q;



if(Main.mipMapping==true && texture.mip!=null) {
texture.rImg=texture.mip[0];
if(texture.drawmode<10 || texture.drawmode>12) {
addmip=q>999 ? 2 : 3;
sizeu=size(au, bu, cu)*texture.rImg.w>>8;
sizev=size(av, bv, cv)*texture.rImg.h>>8;
if(((sizex+sizey)>>1)*addmip<sizeu+sizev) {
texture.rImg=texture.mip[1];
if(texture.mip!=null) {
sizeu>>=1;sizev>>=1;
if(((sizex+sizey)>>1)*addmip<sizeu+sizev) {
texture.rImg=texture.mip[2];
}
}
}
} else {
if(sizex<texture.rImg.w || sizey<texture.rImg.w)  {
    texture.rImg=texture.mip[1];
    if(texture.mip!=null && (sizex<texture.rImg.w || sizey<texture.rImg.w)) {
    texture.rImg=texture.mip[2];
    }
}
}

}


        if(( texture.perspectiveCorrection && (sizex>30-(Main.persQ<3?0:15) || sizey>30-(Main.persQ<3?0:15) ) )&& Main.persQ!=0 || Main.persQ==4) {
            TexturingPers.paint(g3d,
                    texture,
                a, au, av&0xff,
                b, bu, bv&0xff,
                c, cu, cv&0xff,DirectX7.fogc,fog,sz2,q,al0,bl0,cl0,al1,bl1,cl1,al2,bl2,cl2,nx,ny,nz);
        } else {

            TexturingAffine.paint(g3d,
                    texture,
                a, au&0xff, av&0xff,
                b, bu&0xff, bv&0xff,
                c, cu&0xff, cv&0xff,DirectX7.fogc,fog,sz2,al0,bl0,cl0,al1,bl1,cl1,al2,bl2,cl2,nx,ny,nz);
    }
    
}
    
public void renderFast(DirectX7 g3d, Texture texture) {

if(texture.drawmode==5) {
sz2=0xff-dirLight(nx, ny, nz);
if(sz2<0) sz2=0;
}

if(texture.drawmode==1) if(fog==1) szCalcfogAdd();

            TexturingAffine.paint(g3d,
                    texture,
                a, (au), (av),
                b, (bu), (bv),
                c, (cu), (cv),DirectX7.fogc,texture.drawmode,sz2,ar,br,cr,ag,bg,cg,ab,bb,cb,nx,ny,nz);
    
    
}
    private static final int size(int a, int b, int c) {
int t;
        if(b < a) {
            t = a; a = b; b = t;
        }
        if(c < a) {
            t = c; c = a; a = t;
        }
        if(c < b) {
            t = b; b = c; c= t;
        }
        return c - a;
    }
    
}
