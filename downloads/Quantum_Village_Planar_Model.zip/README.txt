Old sym9 village: 4750 -> 4748 triangles; exact plane/UV, boundaries retained.
Original vertex coordinates, source scale6, Tex3 materials 0 forest / 1 map-selo1 / 2 river.
IMPORTANT: planar-neutral.vla is a NEUTRAL255 PLACEHOLDER, NOT a new light bake.
Re-bake light for kordos-planar.3d; do NOT reuse old kordod.vla.
Native runtime must restore kordos-planar.draworder AFTER loading the new lightmap.
Draworder: BE int32 face count, then int16 delta-coded file-face permutation.
Original map/gameplay/collision and texture assets are not replaced.
